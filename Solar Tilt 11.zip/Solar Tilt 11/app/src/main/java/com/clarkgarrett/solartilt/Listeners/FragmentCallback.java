package com.clarkgarrett.solartilt.Listeners;

public interface FragmentCallback {
	public void fragmentMessage(int id);
}
